import React, { useState } from "react";
import { Playlist } from "@/entities/Playlist";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardFooter,
} from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Plus, Palette } from "lucide-react";
import { motion } from "framer-motion";

const themeColors = [
  "#3b82f6",
  "#ef4444",
  "#8b5cf6",
  "#10b981",
  "#f97316",
  "#ec4899",
];

export default function NovaPlaylist() {
  const navigate = useNavigate();
  const [nome, setNome] = useState("");
  const [descricao, setDescricao] = useState("");
  const [corTema, setCorTema] = useState(themeColors[0]);
  const [isCreating, setIsCreating] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!nome.trim()) {
      alert("O nome da playlist é obrigatório.");
      return;
    }
    setIsCreating(true);
    try {
      const newPlaylist = await Playlist.create({
        nome,
        descricao,
        cor_tema: corTema,
        musicas_ids: [],
      });
      navigate(createPageUrl(`Playlist?id=${newPlaylist.id}`));
    } catch (error) {
      console.error("Erro ao criar playlist:", error);
      alert("Não foi possível criar a playlist. Tente novamente.");
    } finally {
      setIsCreating(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-6 flex items-center justify-center">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.3 }}
        className="w-full max-w-lg"
      >
        <Card className="glass-effect border-slate-700/50">
          <CardHeader>
            <CardTitle className="text-2xl font-bold text-white flex items-center gap-3">
              <Plus className="w-6 h-6" />
              Criar Nova Playlist
            </CardTitle>
          </CardHeader>
          <form onSubmit={handleSubmit}>
            <CardContent className="space-y-6">
              <div>
                <Label htmlFor="nome" className="text-white mb-2 block">
                  Nome da Playlist
                </Label>
                <Input
                  id="nome"
                  value={nome}
                  onChange={(e) => setNome(e.target.value)}
                  placeholder="Minha playlist de rock"
                  required
                  className="bg-slate-800/50 border-slate-600 text-white placeholder:text-slate-400"
                />
              </div>
              <div>
                <Label htmlFor="descricao" className="text-white mb-2 block">
                  Descrição (opcional)
                </Label>
                <Textarea
                  id="descricao"
                  value={descricao}
                  onChange={(e) => setDescricao(e.target.value)}
                  placeholder="As melhores para treinar pesado!"
                  className="bg-slate-800/50 border-slate-600 text-white placeholder:text-slate-400"
                />
              </div>
              <div>
                <Label className="text-white mb-3 block flex items-center gap-2">
                  <Palette className="w-4 h-4" />
                  Cor do Tema
                </Label>
                <div className="flex gap-3">
                  {themeColors.map((color) => (
                    <button
                      key={color}
                      type="button"
                      onClick={() => setCorTema(color)}
                      className={`w-8 h-8 rounded-full transition-all duration-200 ${
                        corTema === color
                          ? "ring-2 ring-offset-2 ring-offset-slate-900 ring-white"
                          : ""
                      }`}
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button
                type="submit"
                disabled={isCreating}
                className="w-full bg-gradient-to-r from-blue-600 to-red-600 hover:from-blue-700 hover:to-red-700"
              >
                {isCreating ? "Criando..." : "Criar Playlist"}
              </Button>
            </CardFooter>
          </form>
        </Card>
      </motion.div>
    </div>
  );
}
