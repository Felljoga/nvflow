import React, { useState, useEffect } from "react";
import { Musica, Curtida, Playlist } from "@/entities/all";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Music, TrendingUp, Clock, Upload } from "lucide-react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

import MusicCard from "../components/music/MusicCard";
import MusicPlayer from "../components/player/MusicPlayer";

export default function Home() {
  const [musicasRecentes, setMusicasRecentes] = useState([]);
  const [musicasPopulares, setMusicasPopulares] = useState([]);
  const [curtidas, setCurtidas] = useState([]);
  const [playlists, setPlaylists] = useState([]);
  const [currentMusic, setCurrentMusic] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [musicas, userCurtidas, userPlaylists] = await Promise.all([
        Musica.list("-created_date", 20),
        Curtida.list(),
        Playlist.list(),
      ]);

      setMusicasRecentes(musicas.slice(0, 8));
      setMusicasPopulares(
        musicas
          .sort((a, b) => (b.curtidas || 0) - (a.curtidas || 0))
          .slice(0, 6)
      );
      setCurtidas(userCurtidas);
      setPlaylists(userPlaylists);
    } catch (error) {
      console.error("Erro ao carregar dados:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePlay = (music) => {
    if (currentMusic?.id === music.id) {
      setIsPlaying(!isPlaying);
    } else {
      setCurrentMusic(music);
      setIsPlaying(true);
    }
  };

  const handleLike = async (music) => {
    try {
      const jaTemCurtida = curtidas.find((c) => c.musica_id === music.id);
      if (jaTemCurtida) {
        await Curtida.delete(jaTemCurtida.id);
        setCurtidas((prev) => prev.filter((c) => c.id !== jaTemCurtida.id));
      } else {
        const novaCurtida = await Curtida.create({ musica_id: music.id });
        setCurtidas((prev) => [...prev, novaCurtida]);
      }
    } catch (error) {
      console.error("Erro ao curtir música:", error);
    }
  };

  const handleAddToPlaylist = async (musicId, playlistId) => {
    try {
      const playlist = playlists.find((p) => p.id === playlistId);
      if (!playlist) {
        console.error("Playlist não encontrada.");
        return;
      }

      const currentMusicIds = playlist.musicas_ids || [];
      if (currentMusicIds.includes(musicId)) {
        alert("Essa música já está na playlist!");
        return;
      }

      const updatedMusicIds = [...currentMusicIds, musicId];
      await Playlist.update(playlistId, { musicas_ids: updatedMusicIds });

      setPlaylists((prevPlaylists) =>
        prevPlaylists.map((p) =>
          p.id === playlistId ? { ...p, musicas_ids: updatedMusicIds } : p
        )
      );
      alert("Música adicionada com sucesso!");
    } catch (error) {
      console.error("Erro ao adicionar música à playlist:", error);
      alert("Falha ao adicionar música à playlist.");
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {Array(8)
              .fill(0)
              .map((_, i) => (
                <div
                  key={i}
                  className="glass-effect rounded-xl p-4 animate-pulse"
                >
                  <div className="w-full h-32 bg-slate-700 rounded-lg mb-4"></div>
                  <div className="h-4 bg-slate-700 rounded mb-2"></div>
                  <div className="h-3 bg-slate-700 rounded w-2/3"></div>
                </div>
              ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 pb-24">
      <div className="p-4 sm:p-6 md:p-8">
        <div className="max-w-7xl mx-auto">
          {/* Header Hero */}
          <div className="mb-12">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-8"
            >
              <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-red-400 bg-clip-text text-transparent mb-4">
                Bem-vindo ao NVFlow
              </h1>
              <p className="text-xl text-slate-300 max-w-2xl mx-auto">
                Descubra, organize e curta suas músicas favoritas em um só lugar
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="flex flex-wrap justify-center gap-4"
            >
              <Link to={createPageUrl("Buscar")}>
                <Button className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 shadow-lg">
                  <Music className="w-4 h-4 mr-2" />
                  Explorar Músicas
                </Button>
              </Link>
              <Link to={createPageUrl("Upload")}>
                <Button
                  variant="outline"
                  className="border-slate-600 text-slate-300 hover:bg-slate-700"
                >
                  <Upload className="w-4 h-4 mr-2" />
                  Enviar Música
                </Button>
              </Link>
            </motion.div>
          </div>

          {/* Estatísticas rápidas */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            <Card className="glass-effect border-slate-700/50">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-blue-600/20 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Music className="w-6 h-6 text-blue-400" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">
                  {musicasRecentes.length}
                </h3>
                <p className="text-slate-400">Músicas Disponíveis</p>
              </CardContent>
            </Card>

            <Card className="glass-effect border-slate-700/50">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-red-600/20 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <TrendingUp className="w-6 h-6 text-red-400" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">
                  {curtidas.length}
                </h3>
                <p className="text-slate-400">Suas Curtidas</p>
              </CardContent>
            </Card>

            <Card className="glass-effect border-slate-700/50">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-purple-600/20 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Clock className="w-6 h-6 text-purple-400" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">
                  {Math.floor(
                    musicasRecentes.reduce(
                      (acc, m) => acc + (m.duracao || 0),
                      0
                    ) / 60
                  )}
                </h3>
                <p className="text-slate-400">Minutos de Música</p>
              </CardContent>
            </Card>
          </div>

          {/* Músicas mais populares */}
          {musicasPopulares.length > 0 && (
            <div className="mb-12">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-white flex items-center gap-3">
                  <TrendingUp className="w-6 h-6 text-red-500" />
                  Mais Populares
                </h2>
                <Badge className="bg-red-600/20 text-red-400">Em Alta</Badge>
              </div>
              <div className="grid gap-4">
                {musicasPopulares.map((music) => (
                  <MusicCard
                    key={music.id}
                    music={music}
                    onPlay={handlePlay}
                    onLike={handleLike}
                    isLiked={curtidas.some((c) => c.musica_id === music.id)}
                    isPlaying={currentMusic?.id === music.id && isPlaying}
                    userPlaylists={playlists}
                    onAddToPlaylist={handleAddToPlaylist}
                  />
                ))}
              </div>
            </div>
          )}

          {/* Adicionadas recentemente */}
          {musicasRecentes.length > 0 && (
            <div className="mb-12">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-white flex items-center gap-3">
                  <Clock className="w-6 h-6 text-blue-500" />
                  Adicionadas Recentemente
                </h2>
              </div>
              <div className="grid gap-4">
                {musicasRecentes.map((music) => (
                  <MusicCard
                    key={music.id}
                    music={music}
                    onPlay={handlePlay}
                    onLike={handleLike}
                    isLiked={curtidas.some((c) => c.musica_id === music.id)}
                    isPlaying={currentMusic?.id === music.id && isPlaying}
                    userPlaylists={playlists}
                    onAddToPlaylist={handleAddToPlaylist}
                  />
                ))}
              </div>
            </div>
          )}

          {musicasRecentes.length === 0 && (
            <div className="text-center py-16">
              <div className="w-24 h-24 bg-slate-700/50 rounded-full flex items-center justify-center mx-auto mb-6">
                <Music className="w-12 h-12 text-slate-500" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">
                Nenhuma música encontrada
              </h3>
              <p className="text-slate-400 mb-6">
                Seja o primeiro a adicionar músicas ao NVFlow!
              </p>
              <Link to={createPageUrl("Upload")}>
                <Button className="bg-gradient-to-r from-blue-600 to-red-600 hover:from-blue-700 hover:to-red-700">
                  <Upload className="w-4 h-4 mr-2" />
                  Enviar Primeira Música
                </Button>
              </Link>
            </div>
          )}
        </div>
      </div>

      <MusicPlayer
        currentMusic={currentMusic}
        isPlaying={isPlaying}
        onPlayPause={() => setIsPlaying(!isPlaying)}
        onNext={() => {
          const currentIndex = musicasRecentes.findIndex(
            (m) => m.id === currentMusic?.id
          );
          if (currentIndex < musicasRecentes.length - 1) {
            setCurrentMusic(musicasRecentes[currentIndex + 1]);
          }
        }}
        onPrevious={() => {
          const currentIndex = musicasRecentes.findIndex(
            (m) => m.id === currentMusic?.id
          );
          if (currentIndex > 0) {
            setCurrentMusic(musicasRecentes[currentIndex - 1]);
          }
        }}
        onLike={handleLike}
      />
    </div>
  );
}
