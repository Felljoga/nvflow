import React, { useState, useRef } from "react";
import { Musica } from "@/entities/all";
import { UploadFile } from "@/integrations/Core";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import {
  Upload as UploadIcon,
  Music,
  Image,
  AlertCircle,
  CheckCircle,
  ArrowLeft,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

const generos = [
  { value: "pop", label: "Pop" },
  { value: "rock", label: "Rock" },
  { value: "hip-hop", label: "Hip-Hop" },
  { value: "eletronica", label: "Eletrônica" },
  { value: "indie", label: "Indie" },
  { value: "jazz", label: "Jazz" },
  { value: "classica", label: "Clássica" },
  { value: "sertanejo", label: "Sertanejo" },
  { value: "funk", label: "Funk" },
  { value: "mpb", label: "MPB" },
  { value: "outro", label: "Outro" },
];

export default function Upload() {
  const navigate = useNavigate();
  const [musicData, setMusicData] = useState({
    titulo: "",
    artista: "",
    album: "",
    duracao: "",
    genero: "",
    ano: new Date().getFullYear(),
    arquivo_url: "",
    capa_url: "",
    eh_publica: true,
  });

  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const [dragActive, setDragActive] = useState(false);

  const audioFileRef = useRef(null);
  const imageFileRef = useRef(null);

  const handleInputChange = (field, value) => {
    setMusicData((prev) => ({ ...prev, [field]: value }));
    setError("");
  };

  const handleFileUpload = async (file, type) => {
    try {
      setUploadProgress(20);
      const { file_url } = await UploadFile({ file });
      setUploadProgress(60);

      if (type === "audio") {
        setMusicData((prev) => ({ ...prev, arquivo_url: file_url }));

        // Tentar extrair metadados do arquivo de áudio
        const audio = new Audio(file_url);
        audio.addEventListener("loadedmetadata", () => {
          setMusicData((prev) => ({
            ...prev,
            duracao: Math.floor(audio.duration),
          }));
        });
      } else if (type === "image") {
        setMusicData((prev) => ({ ...prev, capa_url: file_url }));
      }

      setUploadProgress(100);
      setTimeout(() => setUploadProgress(0), 1000);
    } catch (error) {
      setError(
        `Erro ao fazer upload do ${
          type === "audio" ? "arquivo de áudio" : "imagem"
        }`
      );
    }
  };

  const handleDrop = (e, type) => {
    e.preventDefault();
    setDragActive(false);

    const files = Array.from(e.dataTransfer.files);
    const file = files[0];

    if (!file) return;

    if (type === "audio" && !file.type.startsWith("audio/")) {
      setError("Por favor, selecione um arquivo de áudio válido");
      return;
    }

    if (type === "image" && !file.type.startsWith("image/")) {
      setError("Por favor, selecione uma imagem válida");
      return;
    }

    handleFileUpload(file, type);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!musicData.titulo || !musicData.artista || !musicData.arquivo_url) {
      setError(
        "Por favor, preencha os campos obrigatórios e faça upload do arquivo de áudio"
      );
      return;
    }

    setIsUploading(true);
    try {
      await Musica.create(musicData);
      setSuccess(true);
      setTimeout(() => {
        navigate(createPageUrl("Home"));
      }, 2000);
    } catch (error) {
      setError("Erro ao salvar a música. Tente novamente.");
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-6">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate(createPageUrl("Home"))}
            className="border-slate-600 text-slate-300 hover:bg-slate-700"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-white">Upload de Músicas</h1>
            <p className="text-slate-400 mt-1">
              Adicione suas músicas na plataforma NVFlow
            </p>
          </div>
        </div>

        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <Alert variant="destructive" className="mb-6">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            </motion.div>
          )}

          {success && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <Alert className="mb-6 border-green-600 bg-green-600/10">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <AlertDescription className="text-green-600">
                  Música adicionada com sucesso! Redirecionando...
                </AlertDescription>
              </Alert>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Upload de arquivos */}
          <div className="space-y-6">
            <Card className="glass-effect border-slate-700/50">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <UploadIcon className="w-5 h-5" />
                  Arquivos
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Upload de áudio */}
                <div>
                  <Label className="text-white mb-3 block">
                    Arquivo de Áudio *
                  </Label>
                  <div
                    className={`border-2 border-dashed rounded-lg p-6 text-center transition-all duration-300 ${
                      dragActive
                        ? "border-blue-500 bg-blue-500/10"
                        : "border-slate-600 hover:border-slate-500"
                    }`}
                    onDragEnter={(e) => {
                      e.preventDefault();
                      setDragActive(true);
                    }}
                    onDragLeave={(e) => {
                      e.preventDefault();
                      setDragActive(false);
                    }}
                    onDragOver={(e) => e.preventDefault()}
                    onDrop={(e) => handleDrop(e, "audio")}
                  >
                    <input
                      ref={audioFileRef}
                      type="file"
                      accept="audio/*"
                      onChange={(e) =>
                        e.target.files[0] &&
                        handleFileUpload(e.target.files[0], "audio")
                      }
                      className="hidden"
                    />
                    <div className="w-16 h-16 bg-blue-600/20 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Music className="w-8 h-8 text-blue-400" />
                    </div>
                    <p className="text-slate-300 mb-2">
                      {musicData.arquivo_url
                        ? "Arquivo carregado!"
                        : "Arraste o arquivo de áudio aqui"}
                    </p>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => audioFileRef.current?.click()}
                      className="border-slate-600 text-slate-300 hover:bg-slate-700"
                    >
                      Selecionar Arquivo
                    </Button>
                    <p className="text-xs text-slate-500 mt-2">
                      MP3, WAV, OGG - Máximo 50MB
                    </p>
                  </div>
                </div>

                {/* Upload de capa */}
                <div>
                  <Label className="text-white mb-3 block">
                    Capa do Álbum (opcional)
                  </Label>
                  <div
                    className="border-2 border-dashed border-slate-600 rounded-lg p-6 text-center hover:border-slate-500 transition-all duration-300"
                    onDragEnter={(e) => {
                      e.preventDefault();
                      setDragActive(true);
                    }}
                    onDragLeave={(e) => {
                      e.preventDefault();
                      setDragActive(false);
                    }}
                    onDragOver={(e) => e.preventDefault()}
                    onDrop={(e) => handleDrop(e, "image")}
                  >
                    <input
                      ref={imageFileRef}
                      type="file"
                      accept="image/*"
                      onChange={(e) =>
                        e.target.files[0] &&
                        handleFileUpload(e.target.files[0], "image")
                      }
                      className="hidden"
                    />
                    <div className="w-16 h-16 bg-purple-600/20 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Image className="w-8 h-8 text-purple-400" />
                    </div>
                    <p className="text-slate-300 mb-2">
                      {musicData.capa_url
                        ? "Imagem carregada!"
                        : "Arraste a imagem aqui"}
                    </p>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => imageFileRef.current?.click()}
                      className="border-slate-600 text-slate-300 hover:bg-slate-700"
                    >
                      Selecionar Imagem
                    </Button>
                    <p className="text-xs text-slate-500 mt-2">
                      JPG, PNG - Máximo 10MB
                    </p>
                  </div>
                </div>

                {uploadProgress > 0 && (
                  <div className="space-y-2">
                    <Label className="text-white">Progresso do Upload</Label>
                    <Progress value={uploadProgress} className="h-2" />
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Informações da música */}
          <div>
            <Card className="glass-effect border-slate-700/50">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Music className="w-5 h-5" />
                  Informações da Música
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 gap-6">
                    <div>
                      <Label htmlFor="titulo" className="text-white mb-2 block">
                        Título da Música *
                      </Label>
                      <Input
                        id="titulo"
                        value={musicData.titulo}
                        onChange={(e) =>
                          handleInputChange("titulo", e.target.value)
                        }
                        placeholder="Ex: Bohemian Rhapsody"
                        className="bg-slate-800/50 border-slate-600 text-white placeholder:text-slate-400"
                        required
                      />
                    </div>

                    <div>
                      <Label
                        htmlFor="artista"
                        className="text-white mb-2 block"
                      >
                        Artista *
                      </Label>
                      <Input
                        id="artista"
                        value={musicData.artista}
                        onChange={(e) =>
                          handleInputChange("artista", e.target.value)
                        }
                        placeholder="Ex: Queen"
                        className="bg-slate-800/50 border-slate-600 text-white placeholder:text-slate-400"
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="album" className="text-white mb-2 block">
                        Álbum
                      </Label>
                      <Input
                        id="album"
                        value={musicData.album}
                        onChange={(e) =>
                          handleInputChange("album", e.target.value)
                        }
                        placeholder="Ex: A Night at the Opera"
                        className="bg-slate-800/50 border-slate-600 text-white placeholder:text-slate-400"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label
                          htmlFor="genero"
                          className="text-white mb-2 block"
                        >
                          Gênero
                        </Label>
                        <Select
                          onValueChange={(value) =>
                            handleInputChange("genero", value)
                          }
                        >
                          <SelectTrigger className="bg-slate-800/50 border-slate-600 text-white">
                            <SelectValue placeholder="Selecione o gênero" />
                          </SelectTrigger>
                          <SelectContent>
                            {generos.map((genero) => (
                              <SelectItem
                                key={genero.value}
                                value={genero.value}
                              >
                                {genero.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label htmlFor="ano" className="text-white mb-2 block">
                          Ano
                        </Label>
                        <Input
                          id="ano"
                          type="number"
                          min="1900"
                          max={new Date().getFullYear()}
                          value={musicData.ano}
                          onChange={(e) =>
                            handleInputChange("ano", parseInt(e.target.value))
                          }
                          className="bg-slate-800/50 border-slate-600 text-white"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-4 pt-6">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => navigate(createPageUrl("Home"))}
                      className="flex-1 border-slate-600 text-slate-300 hover:bg-slate-700"
                    >
                      Cancelar
                    </Button>
                    <Button
                      type="submit"
                      disabled={
                        isUploading ||
                        !musicData.titulo ||
                        !musicData.artista ||
                        !musicData.arquivo_url
                      }
                      className="flex-1 bg-gradient-to-r from-blue-600 to-red-600 hover:from-blue-700 hover:to-red-700"
                    >
                      {isUploading ? "Salvando..." : "Adicionar Música"}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
