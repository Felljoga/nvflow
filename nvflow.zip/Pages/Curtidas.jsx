import React, { useState, useEffect } from "react";
import { Musica, Curtida, Playlist } from "@/entities/all";
import MusicCard from "../components/music/MusicCard";
import MusicPlayer from "../components/player/MusicPlayer";
import { Heart, Music } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function CurtidasPage() {
  const [likedSongs, setLikedSongs] = useState([]);
  const [curtidasMap, setCurtidasMap] = useState({});
  const [playlists, setPlaylists] = useState([]);
  const [currentMusic, setCurrentMusic] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadLikedSongs();
    loadPlaylists();
  }, []);

  const loadPlaylists = async () => {
    const userPlaylists = await Playlist.list();
    setPlaylists(userPlaylists);
  };

  const loadLikedSongs = async () => {
    setIsLoading(true);
    try {
      const userCurtidas = await Curtida.list();
      const songIds = userCurtidas.map((c) => c.musica_id);

      const curtidasObj = userCurtidas.reduce((acc, c) => {
        acc[c.musica_id] = c.id;
        return acc;
      }, {});
      setCurtidasMap(curtidasObj);

      if (songIds.length > 0) {
        // This is a workaround as there is no `where in` filter
        const allSongs = await Musica.list();
        const liked = allSongs.filter((song) => songIds.includes(song.id));
        setLikedSongs(liked);
      } else {
        setLikedSongs([]);
      }
    } catch (error) {
      console.error("Erro ao carregar músicas curtidas:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePlay = (music) => {
    if (currentMusic?.id === music.id) {
      setIsPlaying(!isPlaying);
    } else {
      setCurrentMusic(music);
      setIsPlaying(true);
    }
  };

  const handleLike = async (music) => {
    const likeId = curtidasMap[music.id];
    if (likeId) {
      await Curtida.delete(likeId);
      setLikedSongs((prev) => prev.filter((song) => song.id !== music.id));
      setCurtidasMap((prev) => {
        const newMap = { ...prev };
        delete newMap[music.id];
        return newMap;
      });
    }
    // No need to handle adding a like on this page as it's for unliking
  };

  const handleAddToPlaylist = async (musicId, playlistId) => {
    const playlist = await playlists.find((p) => p.id === playlistId);
    if (!playlist) return;

    if (playlist.musicas_ids && playlist.musicas_ids.includes(musicId)) {
      alert("Essa música já está na playlist!");
      return;
    }

    const updatedMusicIds = [...(playlist.musicas_ids || []), musicId];
    await Playlist.update(playlistId, { musicas_ids: updatedMusicIds });
    alert("Música adicionada com sucesso!");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 pb-24">
      <div className="p-6 md:p-8">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center gap-4 mb-8">
            <div className="w-16 h-16 bg-gradient-to-br from-red-500 to-pink-500 rounded-lg flex items-center justify-center shadow-lg">
              <Heart className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white">
                Músicas Curtidas
              </h1>
              <p className="text-slate-400">
                Suas faixas favoritas em um só lugar
              </p>
            </div>
          </div>

          <div className="space-y-4">
            {isLoading ? (
              Array(5)
                .fill(0)
                .map((_, i) => (
                  <div
                    key={i}
                    className="glass-effect rounded-xl p-4 animate-pulse"
                  >
                    <div className="h-16 bg-slate-700 rounded-lg"></div>
                  </div>
                ))
            ) : likedSongs.length > 0 ? (
              likedSongs.map((music) => (
                <MusicCard
                  key={music.id}
                  music={music}
                  onPlay={handlePlay}
                  onLike={handleLike}
                  isLiked={!!curtidasMap[music.id]}
                  isPlaying={currentMusic?.id === music.id && isPlaying}
                  userPlaylists={playlists}
                  onAddToPlaylist={handleAddToPlaylist}
                />
              ))
            ) : (
              <Alert className="glass-effect border-slate-700/50 text-center">
                <Music className="h-4 w-4" />
                <AlertTitle className="text-white">
                  Você ainda não curtiu nenhuma música!
                </AlertTitle>
                <AlertDescription className="text-slate-400">
                  Explore o app e clique no coração para salvar suas favoritas
                  aqui.
                </AlertDescription>
              </Alert>
            )}
          </div>
        </div>
      </div>

      <MusicPlayer
        currentMusic={currentMusic}
        isPlaying={isPlaying}
        onPlayPause={() => setIsPlaying(!isPlaying)}
        onLike={handleLike}
      />
    </div>
  );
}
