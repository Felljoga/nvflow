import React, { useState, useEffect } from "react";
import { Musica, Curtida } from "@/entities/all";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Search, Filter, Music, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

import MusicCard from "../components/music/MusicCard";
import MusicPlayer from "../components/player/MusicPlayer";

const generos = [
  { value: "pop", label: "Pop", color: "bg-pink-500/20 text-pink-400" },
  { value: "rock", label: "Rock", color: "bg-red-500/20 text-red-400" },
  {
    value: "hip-hop",
    label: "Hip-Hop",
    color: "bg-purple-500/20 text-purple-400",
  },
  {
    value: "eletronica",
    label: "Eletrônica",
    color: "bg-blue-500/20 text-blue-400",
  },
  { value: "indie", label: "Indie", color: "bg-green-500/20 text-green-400" },
  { value: "jazz", label: "Jazz", color: "bg-yellow-500/20 text-yellow-400" },
  {
    value: "sertanejo",
    label: "Sertanejo",
    color: "bg-orange-500/20 text-orange-400",
  },
  { value: "funk", label: "Funk", color: "bg-pink-600/20 text-pink-300" },
  { value: "mpb", label: "MPB", color: "bg-emerald-500/20 text-emerald-400" },
];

export default function Buscar() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedGenres, setSelectedGenres] = useState([]);
  const [musicas, setMusicas] = useState([]);
  const [musicasFiltradas, setMusicasFiltradas] = useState([]);
  const [curtidas, setCurtidas] = useState([]);
  const [currentMusic, setCurrentMusic] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    loadMusicas();
  }, []);

  useEffect(() => {
    filterMusicas();
  }, [searchTerm, selectedGenres, musicas]);

  const loadMusicas = async () => {
    try {
      const [todasMusicas, userCurtidas] = await Promise.all([
        Musica.list("-created_date"),
        Curtida.list(),
      ]);

      setMusicas(todasMusicas);
      setCurtidas(userCurtidas);
    } catch (error) {
      console.error("Erro ao carregar músicas:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const filterMusicas = () => {
    let filtered = musicas;

    // Filtro por termo de busca
    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(
        (music) =>
          music.titulo.toLowerCase().includes(term) ||
          music.artista.toLowerCase().includes(term) ||
          music.album?.toLowerCase().includes(term)
      );
    }

    // Filtro por gêneros
    if (selectedGenres.length > 0) {
      filtered = filtered.filter((music) =>
        selectedGenres.includes(music.genero)
      );
    }

    setMusicasFiltradas(filtered);
  };

  const toggleGenre = (genero) => {
    setSelectedGenres((prev) =>
      prev.includes(genero)
        ? prev.filter((g) => g !== genero)
        : [...prev, genero]
    );
  };

  const clearFilters = () => {
    setSelectedGenres([]);
    setSearchTerm("");
  };

  const handlePlay = (music) => {
    if (currentMusic?.id === music.id) {
      setIsPlaying(!isPlaying);
    } else {
      setCurrentMusic(music);
      setIsPlaying(true);
    }
  };

  const handleLike = async (music) => {
    try {
      const jaTemCurtida = curtidas.find((c) => c.musica_id === music.id);
      if (jaTemCurtida) {
        await Curtida.delete(jaTemCurtida.id);
        setCurtidas((prev) => prev.filter((c) => c.id !== jaTemCurtida.id));
      } else {
        const novaCurtida = await Curtida.create({ musica_id: music.id });
        setCurtidas((prev) => [...prev, novaCurtida]);
      }
    } catch (error) {
      console.error("Erro ao curtir música:", error);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 pb-24">
      <div className="p-4 sm:p-6 md:p-8">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
              Buscar Músicas
            </h1>
            <p className="text-slate-400">
              Descubra sua próxima música favorita
            </p>
          </div>

          {/* Barra de busca */}
          <Card className="glass-effect border-slate-700/50 mb-8">
            <CardContent className="p-4 md:p-6">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <Input
                    placeholder="Buscar por música, artista ou álbum..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 bg-slate-800/50 border-slate-600 text-white placeholder:text-slate-400 h-12"
                  />
                </div>
                <Button
                  variant="outline"
                  onClick={() => setShowFilters(!showFilters)}
                  className="border-slate-600 text-slate-300 hover:bg-slate-700 h-12 px-6"
                >
                  <Filter className="w-4 h-4 mr-2" />
                  Filtros
                  {selectedGenres.length > 0 && (
                    <Badge className="ml-2 bg-blue-600 text-white">
                      {selectedGenres.length}
                    </Badge>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Filtros */}
          <AnimatePresence>
            {showFilters && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.3 }}
              >
                <Card className="glass-effect border-slate-700/50 mb-8">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="text-lg font-semibold text-white">
                        Filtrar por Gênero
                      </h3>
                      {selectedGenres.length > 0 && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={clearFilters}
                          className="text-slate-400 hover:text-white"
                        >
                          <X className="w-4 h-4 mr-1" />
                          Limpar
                        </Button>
                      )}
                    </div>
                    <div className="flex flex-wrap gap-3">
                      {generos.map((genero) => (
                        <Badge
                          key={genero.value}
                          variant={
                            selectedGenres.includes(genero.value)
                              ? "default"
                              : "outline"
                          }
                          className={`cursor-pointer transition-all duration-200 ${
                            selectedGenres.includes(genero.value)
                              ? genero.color
                              : "border-slate-600 text-slate-400 hover:border-slate-500"
                          }`}
                          onClick={() => toggleGenre(genero.value)}
                        >
                          {genero.label}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Resultados */}
          <div className="space-y-4">
            {isLoading ? (
              <div className="space-y-4">
                {Array(6)
                  .fill(0)
                  .map((_, i) => (
                    <div
                      key={i}
                      className="glass-effect rounded-xl p-4 animate-pulse"
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-16 h-16 bg-slate-700 rounded-lg flex-shrink-0"></div>
                        <div className="flex-1">
                          <div className="h-4 bg-slate-700 rounded mb-2 w-1/3"></div>
                          <div className="h-3 bg-slate-700 rounded w-1/4"></div>
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            ) : musicasFiltradas.length > 0 ? (
              <>
                <div className="flex justify-between items-center mb-6">
                  <p className="text-slate-400">
                    {musicasFiltradas.length} música
                    {musicasFiltradas.length !== 1 ? "s" : ""} encontrada
                    {musicasFiltradas.length !== 1 ? "s" : ""}
                  </p>
                  {(searchTerm || selectedGenres.length > 0) && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={clearFilters}
                      className="text-slate-400 hover:text-white"
                    >
                      <X className="w-4 h-4 mr-1" />
                      Limpar busca
                    </Button>
                  )}
                </div>

                {musicasFiltradas.map((music) => (
                  <MusicCard
                    key={music.id}
                    music={music}
                    onPlay={handlePlay}
                    onLike={handleLike}
                    isLiked={curtidas.some((c) => c.musica_id === music.id)}
                    isPlaying={currentMusic?.id === music.id && isPlaying}
                  />
                ))}
              </>
            ) : (
              <div className="text-center py-16">
                <div className="w-24 h-24 bg-slate-700/50 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Music className="w-12 h-12 text-slate-500" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">
                  {searchTerm || selectedGenres.length > 0
                    ? "Nenhuma música encontrada"
                    : "Nenhuma música disponível"}
                </h3>
                <p className="text-slate-400 mb-6">
                  {searchTerm || selectedGenres.length > 0
                    ? "Tente ajustar seus filtros de busca"
                    : "Seja o primeiro a adicionar músicas!"}
                </p>
                {(searchTerm || selectedGenres.length > 0) && (
                  <Button
                    variant="outline"
                    onClick={clearFilters}
                    className="border-slate-600 text-slate-300 hover:bg-slate-700"
                  >
                    Limpar Filtros
                  </Button>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      <MusicPlayer
        currentMusic={currentMusic}
        isPlaying={isPlaying}
        onPlayPause={() => setIsPlaying(!isPlaying)}
        onNext={() => {
          const currentIndex = musicasFiltradas.findIndex(
            (m) => m.id === currentMusic?.id
          );
          if (currentIndex < musicasFiltradas.length - 1) {
            setCurrentMusic(musicasFiltradas[currentIndex + 1]);
          }
        }}
        onPrevious={() => {
          const currentIndex = musicasFiltradas.findIndex(
            (m) => m.id === currentMusic?.id
          );
          if (currentIndex > 0) {
            setCurrentMusic(musicasFiltradas[currentIndex - 1]);
          }
        }}
        onLike={handleLike}
      />
    </div>
  );
}
