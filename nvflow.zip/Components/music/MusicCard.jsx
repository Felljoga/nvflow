import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Play,
  Heart,
  MoreHorizontal,
  Music,
  ListPlus,
  Pause as PauseIcon,
} from "lucide-react";
import { motion } from "framer-motion";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuSub,
  DropdownMenuSubTrigger,
  DropdownMenuSubContent,
  DropdownMenuPortal,
} from "@/components/ui/dropdown-menu";

export default function MusicCard({
  music,
  onPlay,
  onLike,
  isLiked,
  isPlaying,
  showGenre = true,
  userPlaylists = [],
  onAddToPlaylist,
}) {
  const genreColors = {
    pop: "bg-pink-500/20 text-pink-400",
    rock: "bg-red-500/20 text-red-400",
    "hip-hop": "bg-purple-500/20 text-purple-400",
    eletronica: "bg-blue-500/20 text-blue-400",
    indie: "bg-green-500/20 text-green-400",
    jazz: "bg-yellow-500/20 text-yellow-400",
    classica: "bg-indigo-500/20 text-indigo-400",
    sertanejo: "bg-orange-500/20 text-orange-400",
    funk: "bg-pink-600/20 text-pink-300",
    mpb: "bg-emerald-500/20 text-emerald-400",
    outro: "bg-slate-500/20 text-slate-400",
  };

  const formatDuration = (seconds) => {
    if (!seconds || isNaN(seconds)) return "0:00";
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = Math.floor(seconds % 60);
    return `${minutes}:${remainingSeconds.toString().padStart(2, "0")}`;
  };

  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      transition={{ duration: 0.2 }}
    >
      <Card
        className="glass-effect border-slate-700/50 hover:border-blue-500/30 transition-all duration-300 group cursor-pointer"
        onClick={() => onPlay(music)}
      >
        <CardContent className="p-3 md:p-4">
          <div className="flex items-center gap-3 md:gap-4">
            {/* Capa da música */}
            <div className="relative w-14 h-14 md:w-16 md:h-16 bg-gradient-to-br from-blue-600 to-red-600 rounded-lg flex-shrink-0 flex items-center justify-center shadow-lg overflow-hidden">
              {music.capa_url ? (
                <img
                  src={music.capa_url}
                  alt={music.titulo}
                  className="w-full h-full object-cover"
                />
              ) : (
                <Music className="w-6 h-6 text-white" />
              )}

              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                <Button
                  size="icon"
                  onClick={(e) => {
                    e.stopPropagation();
                    onPlay(music);
                  }}
                  className="w-10 h-10 bg-white/20 hover:bg-white/30 backdrop-blur-sm border-0"
                >
                  {isPlaying ? (
                    <PauseIcon className="w-5 h-5 text-white" />
                  ) : (
                    <Play className="w-5 h-5 text-white ml-0.5" />
                  )}
                </Button>
              </div>
            </div>

            {/* Informações da música */}
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-white truncate group-hover:text-blue-400 transition-colors">
                {music.titulo}
              </h3>
              <p className="text-sm text-slate-400 truncate">{music.artista}</p>
              {showGenre && music.genero && (
                <Badge
                  className={`mt-1 text-xs hidden sm:inline-flex ${
                    genreColors[music.genero] || genreColors.outro
                  }`}
                  variant="secondary"
                >
                  {music.genero}
                </Badge>
              )}
            </div>

            {/* Duração e controles */}
            <div className="flex items-center gap-1 text-slate-400">
              <span className="text-sm min-w-[40px] hidden md:block">
                {formatDuration(music.duracao)}
              </span>
              <Button
                variant="ghost"
                size="icon"
                onClick={(e) => {
                  e.stopPropagation();
                  onLike?.(music);
                }}
                className="opacity-0 group-hover:opacity-100 md:hover:opacity-100 transition-opacity hover:text-red-500"
              >
                <Heart
                  className={`w-4 h-4 ${
                    isLiked ? "fill-red-500 text-red-500" : ""
                  }`}
                />
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={(e) => e.stopPropagation()}
                    className="opacity-0 group-hover:opacity-100 md:hover:opacity-100 transition-opacity hover:text-white"
                  >
                    <MoreHorizontal className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent
                  onClick={(e) => e.stopPropagation()}
                  align="end"
                  className="glass-effect border-slate-700/50"
                >
                  <DropdownMenuLabel>Opções</DropdownMenuLabel>
                  <DropdownMenuSeparator className="bg-slate-700/50" />
                  <DropdownMenuSub>
                    <DropdownMenuSubTrigger>
                      <ListPlus className="mr-2 h-4 w-4" />
                      <span>Adicionar à playlist</span>
                    </DropdownMenuSubTrigger>
                    <DropdownMenuPortal>
                      <DropdownMenuSubContent className="glass-effect border-slate-700/50">
                        <DropdownMenuLabel>Suas Playlists</DropdownMenuLabel>
                        <DropdownMenuSeparator className="bg-slate-700/50" />
                        {userPlaylists.length > 0 ? (
                          userPlaylists.map((pl) => (
                            <DropdownMenuItem
                              key={pl.id}
                              onClick={() => onAddToPlaylist(music.id, pl.id)}
                            >
                              <span>{pl.nome}</span>
                            </DropdownMenuItem>
                          ))
                        ) : (
                          <DropdownMenuItem disabled>
                            Nenhuma playlist
                          </DropdownMenuItem>
                        )}
                      </DropdownMenuSubContent>
                    </DropdownMenuPortal>
                  </DropdownMenuSub>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
