import React, { useState, useRef, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Volume2,
  Heart,
  Repeat,
  Shuffle,
  Music,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function MusicPlayer({
  currentMusic,
  isPlaying,
  onPlayPause,
  onNext,
  onPrevious,
  onLike,
}) {
  const [currentTime, setCurrentTime] = useState(0);
  const [volume, setVolume] = useState(50);
  const [isLiked, setIsLiked] = useState(false); // Manter um estado local para feedback imediato
  const audioRef = useRef(null);

  useEffect(() => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current
          .play()
          .catch((e) => console.error("Erro ao tocar áudio:", e));
      } else {
        audioRef.current.pause();
      }
    }
  }, [isPlaying, currentMusic]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume / 100;
    }
  }, [volume]);

  // Simula a busca da curtida quando a música muda
  useEffect(() => {
    // Em um app real, você verificaria se a música atual está na lista de curtidas do usuário
    // Aqui, vamos apenas resetar para o feedback visual não vazar entre as musicas
    setIsLiked(false);
  }, [currentMusic]);

  const formatTime = (time) => {
    if (isNaN(time) || time === Infinity) return "0:00";
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, "0")}`;
  };

  const handleTimeChange = (value) => {
    const newTime = value[0];
    setCurrentTime(newTime);
    if (audioRef.current) {
      audioRef.current.currentTime = newTime;
    }
  };

  const handleVolumeChange = (value) => {
    setVolume(value[0]);
  };

  const handleLikeClick = () => {
    setIsLiked(!isLiked);
    onLike?.(currentMusic);
  };

  if (!currentMusic) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 100, opacity: 0 }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
        className="fixed bottom-0 left-0 right-0 z-50"
      >
        <Card className="glass-effect border-slate-700/50 rounded-none border-x-0 border-b-0">
          <audio
            ref={audioRef}
            src={currentMusic.arquivo_url}
            onTimeUpdate={(e) => setCurrentTime(e.target.currentTime)}
            onLoadedMetadata={() => {
              if (audioRef.current) {
                audioRef.current.volume = volume / 100;
              }
            }}
            onEnded={onNext}
          />
          <CardContent className="p-3 md:p-4">
            <div className="flex items-center justify-between gap-4">
              {/* Info da música (Esquerda) */}
              <div className="flex items-center gap-3 min-w-0 flex-1">
                <div className="w-12 h-12 md:w-14 md:h-14 bg-gradient-to-br from-blue-600 to-red-600 rounded-lg flex-shrink-0 flex items-center justify-center shadow-lg">
                  {currentMusic.capa_url ? (
                    <img
                      src={currentMusic.capa_url}
                      alt={currentMusic.titulo}
                      className="w-full h-full object-cover rounded-lg"
                    />
                  ) : (
                    <Music className="w-6 h-6 text-white" />
                  )}
                </div>
                <div className="min-w-0 hidden md:block">
                  <h4 className="font-semibold text-white truncate">
                    {currentMusic.titulo}
                  </h4>
                  <p className="text-sm text-slate-400 truncate">
                    {currentMusic.artista}
                  </p>
                </div>
              </div>

              {/* Controles Centrais (Desktop) */}
              <div className="hidden md:flex flex-col items-center gap-2 flex-1 max-w-lg">
                <div className="flex items-center gap-4">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-slate-400 hover:text-white"
                  >
                    <Shuffle className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={onPrevious}
                    className="text-slate-300 hover:text-white"
                  >
                    <SkipBack className="w-5 h-5" />
                  </Button>
                  <Button
                    onClick={onPlayPause}
                    className="w-10 h-10 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 shadow-lg"
                  >
                    {isPlaying ? (
                      <Pause className="w-5 h-5" />
                    ) : (
                      <Play className="w-5 h-5 ml-0.5" />
                    )}
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={onNext}
                    className="text-slate-300 hover:text-white"
                  >
                    <SkipForward className="w-5 h-5" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-slate-400 hover:text-white"
                  >
                    <Repeat className="w-4 h-4" />
                  </Button>
                </div>

                <div className="flex items-center gap-2 w-full max-w-md">
                  <span className="text-xs text-slate-400 min-w-[40px] text-right">
                    {formatTime(currentTime)}
                  </span>
                  <Slider
                    value={[currentTime]}
                    max={currentMusic.duracao || 200}
                    step={1}
                    onValueChange={handleTimeChange}
                    className="flex-1"
                  />
                  <span className="text-xs text-slate-400 min-w-[40px]">
                    {formatTime(currentMusic.duracao || 200)}
                  </span>
                </div>
              </div>

              {/* Controles da Direita */}
              <div className="flex items-center justify-end gap-2">
                {/* Controles Mobile */}
                <div className="flex md:hidden items-center gap-1">
                  <div className="block md:hidden mr-2 min-w-0 text-left">
                    <h4 className="font-semibold text-white text-sm truncate">
                      {currentMusic.titulo}
                    </h4>
                    <p className="text-xs text-slate-400 truncate">
                      {currentMusic.artista}
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={handleLikeClick}
                    className="text-slate-400 hover:text-red-500"
                  >
                    <Heart
                      className={`w-5 h-5 transition-all ${
                        isLiked ? "fill-red-500 text-red-500" : ""
                      }`}
                    />
                  </Button>
                  <Button
                    onClick={onPlayPause}
                    size="icon"
                    className="w-10 h-10 bg-gradient-to-r from-blue-600 to-red-600 shadow-lg"
                  >
                    {isPlaying ? (
                      <Pause className="w-5 h-5" />
                    ) : (
                      <Play className="w-5 h-5 ml-0.5" />
                    )}
                  </Button>
                </div>

                {/* Controles Desktop */}
                <div className="hidden md:flex items-center gap-2 flex-1 justify-end max-w-xs">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={handleLikeClick}
                    className="text-slate-400 hover:text-red-500"
                  >
                    <Heart
                      className={`w-5 h-5 transition-all ${
                        isLiked ? "fill-red-500 text-red-500" : ""
                      }`}
                    />
                  </Button>
                  <Volume2 className="w-4 h-4 text-slate-400" />
                  <Slider
                    value={[volume]}
                    max={100}
                    step={1}
                    onValueChange={handleVolumeChange}
                    className="w-24"
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </AnimatePresence>
  );
}
